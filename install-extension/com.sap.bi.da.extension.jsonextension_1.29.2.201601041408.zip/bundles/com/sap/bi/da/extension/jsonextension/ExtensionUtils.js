jQuery.sap.declare("com.sap.bi.da.extension.jsonextension.ExtensionUtils");

com.sap.bi.da.extension.jsonextension.ExtensionUtils = function() {};

com.sap.bi.da.extension.jsonextension.ExtensionUtils.prototype.dummy = function(n)
{
	  

	  return "dummy";
}

